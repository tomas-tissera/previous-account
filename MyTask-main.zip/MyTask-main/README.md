
# MyTasks React
La intención del proyecto es podes ayudar y gestionar las tareas diarias de los usuario , simplificando un espacio en el se pueda cargar diferentes tareas ademas de permitir agregar listados, imagenes, color de papeleta y categorias, para poder personalizar la tareas.
## Tabla de Contenidos

- [Instalación](#instalación)
- [Uso](#uso)
- [Contacto](#contacto)
- [Install](#install)

## Instalación

Instrucciones detalladas para instalar el proyecto. Puede incluir comandos de terminal y otros requisitos.

```bash
git clone https://github.com/TomasTissera/MyTask.git
cd FirstAppReact
npm install
npm run dev
```
## Uso

La App pide de forma obligatoria el ´titulo´ y la ´descripcion´ ademas de ellos se puede agregar un "listado" , cambiar el "color" de la papeleta , agregar una "imagen" y agregar "categorias" a dicha tarea.Pudiendo asi permitir una mayor personalizacion de la tarea para qur permita espesificar mas la misma.
Se puede filtrar por agregador anteriormente nombrados ademas de poder eliminar tareas.

## Install 
Algunas de las Dependencias usadas:
```bash
npm install 
```

## Contacto
Para cualquier duda, sugerencia o colaboración, puedes contactarme a través de los siguientes medios: 
-  **Nombre:** Tomas Tissera 
-   **Email:** [tomas.tissera.trabajo@gmail.com](mailto:tomas.tissera.trabajo@gmail.com) 
-  **GitHub:** [TomasTissera](https://github.com/TomasTissera) 
- **LinkedIn:** [Tomas Tissera](www.linkedin.com/in/tomás-tissera-340b471a8)
-  **Sitio Web Personal:** [https://tomas-tissera.netlify.app/](https://tomas-tissera.netlify.app/)

¡Estoy deseando escuchar tus comentarios y sugerencias!


