import React, { useState } from 'react';
import styles from './SavedFormsList.module.css';

function SavedFormsList({ forms, onDeleteForm }) {
  const [filter, setFilter] = useState('all');

  const handleFilterChange = (event) => {
    setFilter(event.target.value);
  };

  const filteredForms = forms.filter((form) => {
    if (filter === 'all') return true;
    if (filter === 'lista') return form.categories.some(cat => cat.value === 'lista');
    if (filter === 'img') return form.categories.some(cat => cat.value === 'img');
    if (filter === 'categoria') return form.categories.some(cat => cat.value === 'categoria');
    return false;
  });

  return (
    <div className={styles.savedFormsListContainer}>
<div className={styles.filterContainer}>
            <label className={styles.filtroText}>
              Filtrar por: 
              <select value={filter} onChange={handleFilterChange} className={styles.filterSelect}>
                <option value="all">Todos</option>
                <option value="lista">Lista</option>
                <option value="img">Imagen</option>
                <option value="categoria">Categoría</option>
              </select>
            </label>
          </div>
      {filteredForms.length === 0 ? (
        <p className={styles.tareasVacio}>¡No hay tareas guardadas!☹</p>
      ) : (

        <div className={styles.contenedorPadre}>
          <h2>Formularios:</h2>
          
          <div className={styles.savedFormsListContainerOk}>
            {filteredForms.map((form, index) => (
              <div key={index} className={styles.formItem} style={{ backgroundColor: form.color.value }}>
                <div className={styles.fromInfo}>
                  <div className={styles.formTitle}>
                    <h2>Título:</h2>
                    <h3>{form.title}</h3>
                  </div>
                  <p>Fecha de Creación: {new Date(form.creationDate).toLocaleDateString()}</p>
                  <div className={styles.formDescription}>
                    Descripción: <br />
                    {form.description}
                  </div>
                  {form.categories && form.categories.some(cat => cat.value === 'lista') && form.lista && (
                    <div className={styles.listaContainer}>
                      <h4>Lista:</h4>
                      <ul className={styles.listaGuardada}>
                        {form.lista.map((item, idx) => (
                          <li key={idx}>{item}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  {form.categories && form.categories.some(cat => cat.value === 'img') && form.imagen && (
                    <div className={styles.imagenContainer}>
                      <h4>Imagen:</h4>
                      <img src={form.imagen} alt="Imagen guardada" className={styles.imagenGuardada} />
                    </div>
                  )}
                  {form.categories && form.categories.some(cat => cat.value === 'categoria') && form.cat && (
                    <div className={styles.categoriaContainer}>
                      <h4>Categorías:</h4>
                      <ul className={styles.categoriaLista}>
                        {form.cat.map((catItem, idx) => (
                          <li key={idx}>
                            <p>{catItem.label}</p>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>
                <button className={styles.deleteButton} onClick={() => onDeleteForm(form.id)}>Eliminar</button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export default SavedFormsList;
