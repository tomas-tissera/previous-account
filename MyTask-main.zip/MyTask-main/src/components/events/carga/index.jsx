import React, { useState, useEffect } from 'react';
import SavedFormsList from '../Tareas/index';
import styles from './carga.module.css';
import Swal from 'sweetalert2';
import Select from 'react-select';
import { FaTrash } from "react-icons/fa";

const categoriesOptions = [
  { value: 'lista', label: 'Lista' },
  { value: 'color', label: 'Color' },
  { value: 'img', label: 'Img' },
  { value: 'categoria', label: 'Categoria' },
];
const catOptions = [
  { value: 'Super', label: 'Super' },
  { value: 'Casa', label: 'Casa' },
  { value: 'Patio', label: 'Patio' },
  { value: 'Auto', label: 'Auto' },
  { value: 'Educacion', label: 'Educacion' },
  { value: 'Pagar', label: 'Pagar' },
  { value: 'Etc', label: 'Etc' },
];
const colorOptions = [
  { value: 'rgb(245, 222, 192)', label: 'Papel' },
  { value: 'rgb(221, 151, 151)', label: 'Rojo' },
  { value: 'rgb(151, 167, 221)', label: 'Azul' },
  { value: 'rgb(159, 221, 151)', label: 'Verde' },
  { value: 'rgb(216, 175, 129)', label: 'Naranja' },
];

function Formulario() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [savedForms, setSavedForms] = useState([]);
  const [errorMessage, setErrorMessage] = useState('');
  const [selectedCategories, setSelectedCategories] = useState([]);
  const [selectedCat, setSelectedCat] = useState([]);
  const [selectedColor, setSelectedColor] = useState(colorOptions[0]); // Default to red
  const [lista, setLista] = useState([]);
  const [nuevoElemento, setNuevoElemento] = useState('');
  const [selectedImage, setSelectedImage] = useState(null);
  const [imageBase64, setImageBase64] = useState(null);

  useEffect(() => {
    const savedFormsFromLocalStorage = JSON.parse(localStorage.getItem('savedForms')) || [];
    setSavedForms(savedFormsFromLocalStorage);
  }, []);

  const convertToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });
  };

  const saveForm = async () => {
    const newForm = {
      id: new Date().getTime(),
      title,
      description,
      categories: selectedCategories,
      lista: selectedCategories.some(cat => cat.value === 'lista') ? lista : [],
      color: selectedColor,
      creationDate: new Date().toISOString(),
      imagen: imageBase64,
      cat: selectedCat,
    };
    const updatedForms = [...savedForms, newForm];
    console.log(newForm);
    setSavedForms(updatedForms);
    localStorage.setItem('savedForms', JSON.stringify(updatedForms));
  };

  const handleDeleteForm = (id) => {
    const updatedForms = savedForms.filter((form) => form.id !== id);
    setSavedForms(updatedForms);
    localStorage.setItem('savedForms', JSON.stringify(updatedForms));
  };

  const handleTitleChange = (event) => {
    setTitle(event.target.value);
  };

  const handleDescriptionChange = (event) => {
    setDescription(event.target.value);
  };

  const handleCategoryChange = (selectedOptions) => {
    setSelectedCategories(selectedOptions);
  };
  const handleCatChange = (selectedOptions) => {
    setSelectedCat(selectedOptions);
  };
  const handleColorChange = (selectedOption) => {
    setSelectedColor(selectedOption);
  };

  const handleImageChange = async (event) => {
    const imageFile = event.target.files[0];
    setSelectedImage(imageFile);
    const base64 = await convertToBase64(imageFile);
    setImageBase64(base64);
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (title.trim() === '' || description.trim() === '') {
      Swal.fire({
        title: '¡Atención!',
        text: 'El título y la descripción no pueden estar vacíos',
        icon: 'info',
      });
      setErrorMessage('El título y la descripción son obligatorios');
      return;
    }

    setErrorMessage('');
    saveForm();
    setTitle('');
    setDescription('');
    setSelectedCategories([]);
    setSelectedColor(colorOptions[0]); // Reset to default color (red)
    setSelectedImage(null);
    setImageBase64(null);
    setLista([]);
    setSelectedCat([])
  };

  const agregarElemento = (event) => {
    event.preventDefault();
    if (nuevoElemento.trim() !== '') {
      const updatedLista = [...lista, nuevoElemento];
      setLista(updatedLista);
      setNuevoElemento('');
      const updatedForms = savedForms.map(form => 
        form.categories.some(cat => cat.value === 'lista') ? { ...form, lista: updatedLista } : form
      );
      localStorage.setItem('savedForms', JSON.stringify(updatedForms));
    }
  };

  const eliminarElemento = (index) => {
    event.preventDefault();
    const updatedLista = lista.filter((_, idx) => idx !== index);
    setLista(updatedLista);
    const updatedForms = savedForms.map(form => 
      form.categories.some(cat => cat.value === 'lista') ? { ...form, lista: updatedLista } : form
    );
    setSavedForms(updatedForms);
    localStorage.setItem('savedForms', JSON.stringify(updatedForms));
  };
  
  const isColorSelected = selectedCategories.some((cat) => cat.value === 'color');
  const isListSelected = selectedCategories.some((cat) => cat.value === 'lista');
  const isImgSelected = selectedCategories.some((cat) => cat.value === 'img');
  const isCatSelected = selectedCategories.some((cat) => cat.value === 'categoria');


  const CUSTOM_NAVIGATION_SELECT = { // styles de los select
    control: (baseStyles, state) => ({
      ...baseStyles,
      backgroundColor: state.isFocused ? 'rgba(0, 0, 0, 0.1)' : 'rgba(0, 0, 0, 0.1)',
      borderColor: state.isFocused ? 'neutral30' : 'neutral30',
      whiteSpace: state.isFocused ? '50px' : '50px',
      color: 'rgba(146, 132, 114, 0.322)',
      "@media only screen and (max-width: 450px)": {
        backgroundColor:"rgba(0, 0, 0, 0.1)",
        width: "300px",
        borderColor:  'neutral30',
        whiteSpace: '50px',
        
    },
    }),
}
  return (
    <div className={styles.contenedorFormulario}>
      <div className={styles.crearFormularios}>
        <h2>Crear Nueva Tarea</h2>
        <form
          id='ticket'
          className={styles.home}
          onSubmit={handleSubmit}
          style={{ backgroundColor: selectedColor ? selectedColor.value : 'rgb(245, 222, 192)' }}
        >
          <div className={styles.triangulo}></div>
            <div>

              <label className={styles.label}>
                <input
                  type="text"
                  value={title}
                  onChange={handleTitleChange}
                  className={styles.inputTitul}
                  placeholder="Introduce el Título"
                />
              </label>
              <br />
              <label className={styles.label}>
                <textarea
                  value={description}
                  onChange={handleDescriptionChange}
                  className={styles.input}
                  placeholder="Introduce la Descripción"
                />
              </label>
            </div>
          <br />
          <div className={styles.boxSelect}>
            <label className={styles.label}>
              Agregados:
              <Select
                isMulti
                options={categoriesOptions}
                value={selectedCategories}
                onChange={handleCategoryChange}
                
                styles={CUSTOM_NAVIGATION_SELECT}
              />
            </label>
          </div>

          {isColorSelected && (
            <div className={styles.coloreContenedor}>
              <h3>Colores</h3>
              <div className={styles.coloreContenedorSelect}>
                <Select
                  options={colorOptions}
                  value={selectedColor}
                  onChange={handleColorChange}
                  styles={{
                    control: (baseStyles, state) => ({
                      ...baseStyles,
                      backgroundColor: state.isFocused ? 'rgba(0, 0, 0, 0.20)' : 'rgba(0, 0, 0, 0.20)',
                      borderColor: state.isFocused ? 'neutral30' : 'neutral30',
                      whiteSpace: state.isFocused ? '80px' : '80px',
                      color: 'rgba(146, 132, 114, 0.322)',
                      menuPlacement: "auto",
                      menuPosition: "fixed"

                    }),
                  }}
                />
              </div>
            </div>
          )}
          {isListSelected && (
            <div className={styles.contenedorCargaLista}>
              <h3 className={styles.titleLista}>Lista</h3>
              <div className={styles.agregarLista}>
                <input
                  className={styles.inputElementoLista}
                  type="text"
                  value={nuevoElemento}
                  onChange={(e) => setNuevoElemento(e.target.value)}
                  placeholder="Escribe un nuevo elemento"
                  onKeyDown={(e) => {
                    if (e.key === 'Enter') {
                      agregarElemento(e);
                    }
                  }}
                />
                <button id='agregarItem' onClick={agregarElemento} className={styles.botonLista}>Agregar</button>
              </div>
              <ul className={styles.lista}>
                {lista.map((elemento, index) => (
                  <li key={index} className={styles.conetenedorElementoLista}>
                    {elemento}
                    <button onClick={() => eliminarElemento(index)} className={styles.deleteLista}><FaTrash /></button>
                  </li>
                ))}
              </ul>
            </div>
          )}
          {isImgSelected && (
           <div className={styles.contenedorCargaLista}>
           <h3 className={styles.titleLista}>Imagen</h3>
           <div className={styles.agregarImagen}>
              <div class="flex items-center justify-center w-full">
                  <label for="dropzone-file" class="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 dark:hover:bg-bray-800 dark:bg-gray-700 hover:bg-gray-100 dark:border-gray-600 dark:hover:border-gray-500 dark:hover:bg-gray-600">
                      <div class="flex flex-col items-center justify-center pt-5 pb-6">
                          
                          {selectedImage ? (
                            <div className={styles.previewImage}>
                              <img
                                src={URL.createObjectURL(selectedImage)}
                                alt="Previsualización"
                                className={styles.imgPreview}
                              />
                            </div>
                          ):(
                            <svg class="w-8 h-8 mb-4 text-gray-500 dark:text-gray-400" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 16">
                              <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 13h3a3 3 0 0 0 0-6h-.025A5.56 5.56 0 0 0 16 6.5 5.5 5.5 0 0 0 5.207 5.021C5.137 5.017 5.071 5 5 5a4 4 0 0 0 0 8h2.167M10 15V6m0 0L8 8m2-2 2 2"/>
                          </svg>
                          )}
                      </div>
                      <input id="dropzone-file" type="file" 
                      accept="image/*"
                      onChange={handleImageChange}
                      className={styles.inputFile} />
                  </label>
              </div> 

             
           </div>
         </div>
          )}
          {isCatSelected && (
           <div className={styles.boxSelect}>
           <label className={styles.label}>
             Categoria/s:
             <Select
               isMulti
               options={catOptions}
               value={selectedCat}
               onChange={handleCatChange}
               styles={CUSTOM_NAVIGATION_SELECT}
             />
           </label>
         </div>
          )}

          <button id='agregarTarea' type="submit" className={styles.boton}>
            Guardar
          </button>
        </form>

        {errorMessage && <div className={styles.error}>{errorMessage}</div>}
      </div>

      <SavedFormsList forms={savedForms} onDeleteForm={handleDeleteForm} />
    </div>
  );
}

export default Formulario;
