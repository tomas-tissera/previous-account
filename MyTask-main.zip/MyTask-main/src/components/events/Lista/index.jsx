import React, { useState, useEffect } from 'react';

const ListaViw = () => {
  const [lista, setLista] = useState([]);
  const [nuevoElemento, setNuevoElemento] = useState('');

  useEffect(() => {
    const savedListFromLocalStorage = JSON.parse(localStorage.getItem('lista')) || [];
    setLista(savedListFromLocalStorage);
  }, []);

  useEffect(() => {
    localStorage.setItem('lista', JSON.stringify(lista));
  }, [lista]);

  const agregarElemento = (event) => {
    event.preventDefault(); // Evita el comportamiento predeterminado del formulario
    if (nuevoElemento.trim() !== '') {
      const updatedList = [...lista, nuevoElemento];
      setLista(updatedList); // Agregar el elemento a la lista
      setNuevoElemento(''); // Limpiar el campo de entrada
    }
  };

  return (
    <div>
      <h1>Lista Editable</h1>
      <input
        type="text"
        value={nuevoElemento} // Valor del campo de entrada
        onChange={(e) => setNuevoElemento(e.target.value)} // Actualizar el valor del campo cuando cambia
        placeholder="Escribe un nuevo elemento"
        onKeyDown={(e) => {
          if (e.key === 'Enter') {
            agregarElemento(e); // Agregar el elemento al presionar "Enter"
          }
        }}
      />
      <button id='agregarItem' onClick={agregarElemento}>Agregar</button> {/* Botón para agregar el elemento */}
      <ul>
        {lista.map((elemento, index) => (
          <li key={index}>{elemento}</li> // Renderizar la lista de elementos
        ))}
      </ul>
    </div>
  );
};

export default ListaViw;
