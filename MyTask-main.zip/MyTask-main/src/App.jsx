import Router from "./routes/index";
import './App.css'

function App() {
  return <Router/>
}

export default App