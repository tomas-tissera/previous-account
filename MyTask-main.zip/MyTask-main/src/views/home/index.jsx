import Carga from "../../components/events/carga"
const Home = () => {
    
    
    return (
        <>
          <div>
            <Carga/>
          </div>
          
        </>
      )};
export default Home;