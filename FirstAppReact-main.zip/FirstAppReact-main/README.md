
# My First application with React
La intención del proyecto es que se muestren resultados de eventos en el país (MEX) donde se este creando el proyecto. Eventos que estén a cargo de la boletera Ticketmaster. Al darle click a a un evento, los usuarios serán capaces de ir a ver el detalle del evento, en donde verán mas a detalle de la información del evento.

## Tabla de Contenidos

- [Instalación](#instalación)
- [Uso](#uso)
- [Contacto](#contacto)
- [Install](#install)

## Instalación

Instrucciones detalladas para instalar el proyecto. Puede incluir comandos de terminal y otros requisitos.

```bash
git clone https://github.com/TomasTissera/FirstAppReact.git
cd FirstAppReact
npm install
npm run dev
```
## Uso

La Pagina hace un pedido a la Api de [Ticketmaster](https://www.ticketmaster.com/) para así poder llamar a los diversos eventos que se gestionan por ella , en esta pagina se puede filtrar por nombre además de poder darle ´Fav´ y así poder verla en un apartado especial en Home , además en el Home podemos cargar nuestros datos como ´Nombre´-´Mail´-´Edad´ y que se guarde de forma local.

## Install 
Algunas de las Dependencias usadas:
```bash
npm install react-hook-form
npm install react-router-dom localforage match-sorter sort-by
npm install react-paginate --save
npm install date-fns --save
npm install wrap-promise
npm install zustand
```

## Contacto
Para cualquier duda, sugerencia o colaboración, puedes contactarme a través de los siguientes medios: 
-  **Nombre:** Tomas Tissera 
-   **Email:** [tomas.tissera.trabajo@gmail.com](mailto:tomas.tissera.trabajo@gmail.com) 
-  **GitHub:** [TomasTissera](https://github.com/TomasTissera) 
- **LinkedIn:** [Tomas Tissera](www.linkedin.com/in/tomás-tissera-340b471a8)
-  **Sitio Web Personal:** [https://tomas-tissera.netlify.app/](https://tomas-tissera.netlify.app/)

¡Estoy deseando escuchar tus comentarios y sugerencias!


