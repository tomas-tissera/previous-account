import { useState, useEffect, forwardRef, useImperativeHandle } from "react";
import { Link } from "react-router-dom";
import { CiUser } from "react-icons/ci";
import styles from "./navbar.module.css"
const Navbar = forwardRef(({ onSearch }, ref) => {
    const [search, setSearch] = useState('');

    useEffect(() => {
        // console.log('onSearch cambio');
    }, [onSearch]);

    useEffect(() => {
        // console.log('Componente listo');
    }, []);

    useEffect(() => {
        // console.log('search cambio');
    }, [search]);

    useImperativeHandle(ref, () => ({
        search,
        setSearch,
    }));

    const handleInputChange = (evt) => {
        setSearch(evt.target.value);
    };

    const handleInputKeyDown = (evt) => {
        if (evt.key === 'Enter') {
            onSearch(search);
        }
    };
    
    return (
        <div ref={ref} 
            className={styles.navbarContenedor}
        style={{
            
        }}>
            <div className={styles.navbarTex}>
                <p style={{
                    fontSize: 32,
                    fontWeight: 'bold',
                    color: 'hsl(57deg 100% 48%)',
                }}>M</p>
                <p style={{
                    fontSize: 24,
                }}>i</p>
                <p style={{
                    fontSize: 32,
                    fontWeight: 'bold',
                    color: 'hsl(57deg 100% 48%)',
                }}>B</p>
                 <p style={{
                    fontSize: 24,
                }}>oletera</p>
            </div>
            <div  className={styles.searchIcon}>
                <input
                    placeholder="Buscar Evento"
                    onChange={handleInputChange}
                    onKeyDown={handleInputKeyDown}
                    value={search}
                    className={styles.searchNavbar}
                />
                <Link to="/profile/my-info" 
                    className={styles.iconoHome}
                >
                    <CiUser  
                    style={{
                        color: 'black',
                        width: '30px',
                        height: '30px',
                    }} 
                    />
                </Link>
            </div>
        </div>
    );
});

Navbar.displayName = 'Navbar';

export default Navbar;