

const MyInfo = () =>{
    
    return(
        
        <div>
            <p>f</p>
        </div>
    );
};
export default MyInfo;