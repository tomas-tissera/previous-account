

const LikedEvents = () =>{
    
    
    return(
        <div>
            
            <h4>
                LikedEvents
            </h4>
        </div>
    );
};
export default LikedEvents;