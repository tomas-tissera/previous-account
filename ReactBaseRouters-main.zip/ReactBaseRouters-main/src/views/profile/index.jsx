
import styles from "./profile.module.css"


const Profile = () =>{
   
    return(
        <div className={styles.homeContainer}>
            <h4>profilsssse</h4>
        </div>
    );
}
export default Profile;