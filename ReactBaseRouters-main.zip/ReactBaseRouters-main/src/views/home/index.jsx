import Navbar from "../../components/navbar";
const Home = () => {
   
    return (
        <>
           <div>
                <Navbar/>
                Homee
            </div>
        </>
)};
export default Home;