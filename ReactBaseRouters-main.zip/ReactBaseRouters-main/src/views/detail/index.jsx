
import styles from "./detail.module.css";

const Detail = () =>{ 
   
    return(
        <div className={styles.container}>
            
            <h4>detallesss</h4>
        </div>
    );
}
export default Detail;