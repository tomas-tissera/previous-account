import 'package:flutter/material.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';
import 'pages/pageCalendario.dart';
import 'pages/pageHome.dart';
import 'pages/pageTareas.dart';
import 'pages/pageCursos.dart';
import 'pages/othePage.dart';
void main() => runApp(MaterialApp(home: BottomNavBar()));

class BottomNavBar extends StatefulWidget {
  @override
  _BottomNavBarState createState() => _BottomNavBarState();
}

class _BottomNavBarState extends State<BottomNavBar> {
  int pageIndex = 0;
  final PageHome _home = PageHome();
  final PageCalendario _calendario = new PageCalendario();
  final PageTareas _tareas = new PageTareas();
  final PageCursos _cursos = new PageCursos();
  final OtherPage _otherPage = new OtherPage();
  Widget _showPage = new PageHome();
  Widget _pageChooser(int page){
    switch (page){
      case 0:
      return _home;
      break;
      case 1:
      return _calendario;
      break;
      case 2:
      return _tareas;
      break;
      case 3:
      return _cursos;
      break;
      case 4:
      return _otherPage;
      break;
      default : 
      return new Container(
        child: new Center(
          child: new Text(
            "No Page found by page  choooser.",
            style: new TextStyle(fontSize : 30),
          ),
        )
      );
    }
  }

  GlobalKey _bottomNavigationKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: CurvedNavigationBar(
          key: _bottomNavigationKey,
          index: pageIndex,
          height: 50.0,
          items: <Widget>[
            Icon(Icons.home, size: 30),
            Icon(Icons.calendar_today, size: 30),
            Icon(Icons.book, size: 30),
            Icon(Icons.library_books, size: 30),
            Icon(Icons.perm_identity, size: 30),
          ], 
          color: Colors.black38,
          buttonBackgroundColor: Colors.grey,
          backgroundColor: Colors.white,
          animationCurve: Curves.easeInOut,
          animationDuration: Duration(milliseconds: 600),
          onTap: (int tappedIndex) {
            setState(() {
              _showPage = _pageChooser(tappedIndex);
            });
          },
        ),
        body: Container(
          color: Colors.white,
          child: Center(
            child: _showPage,
          ),
        ));
  }
}