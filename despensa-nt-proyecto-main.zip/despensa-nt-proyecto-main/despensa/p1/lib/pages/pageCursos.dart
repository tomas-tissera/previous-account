import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class PageCursos extends StatelessWidget {
  Widget build(BuildContext context) {
    return Scaffold(
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          // Add your onPressed code here!
        },
        child: Icon(Icons.add),
        foregroundColor: Colors.black,
        backgroundColor: Colors.grey,
        
      ),
      body: Container(
          color: Colors.white,
          ),
    );
  }
}
