import 'package:flutter/cupertino.dart';

class PageCalendario extends StatelessWidget {
  
  @override
  Widget build(BuildContext context) {
    return Container(
      child : Text("Calendario " , textScaleFactor: 2.0, ),
    );
  }
}


