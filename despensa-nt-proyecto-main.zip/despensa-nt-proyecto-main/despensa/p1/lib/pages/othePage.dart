import 'package:flutter/cupertino.dart';

class OtherPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child : Text("Other " , textScaleFactor: 2.0, ),
    );
  }
}