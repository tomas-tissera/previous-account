import 'package:flutter/cupertino.dart';

class PageHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child : Text("Home " , textScaleFactor: 2.0, ),
    );
  }
}